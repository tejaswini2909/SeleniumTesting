package com.cg.project;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {


	@FindBy(id="login_field")
	WebElement userName;

	@FindBy(id="password")
	WebElement password;

	@FindBy(className="btn")
	WebElement button;

	public LoginPage(){}

	public WebElement getUserName() {
		return userName;
	}

	public void setUsername(String userName){
		this.userName.sendKeys(userName);
	}
	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password){
		this.password.sendKeys(password);
	}

	public void clickSubmitButton(){
		button.submit();
	}
	
}
