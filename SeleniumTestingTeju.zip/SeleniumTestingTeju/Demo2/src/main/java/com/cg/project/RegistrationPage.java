package com.cg.project;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage {


	@FindBy(id="user_login")
	WebElement username;
	
	@FindBy(id="user_email")
	WebElement EmailID;
	
	@FindBy(id="user_password")
	WebElement password;
	@FindBy(className = "btn")
	WebElement button;
	public RegistrationPage() {}
	
	public WebElement getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username.sendKeys(username);
	}
	public WebElement getEmailID() {
		return EmailID;
	}
	public void setEmailID(String emailID) {
		this.EmailID.sendKeys(emailID);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public void clickSubmitButton() {
		button.submit();
	}
	
}
