package com.cg.demotest.Demo2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.LoginPage;

public class LoginTest {
	public static WebDriver driver;
	private LoginPage loginPage;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Before
	public void setUpTestEnv() {
		driver.get("https://github.com/login");
		loginPage = new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}
	
	@Test
	public void testForBlankUserNameAndPassword() {
		loginPage.setUsername("");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndInvalidPassword() {
		loginPage.setUsername("samykya-thanuku");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForInvalidUserNameAndValidPassword() {
		loginPage.setUsername("");
		loginPage.setPassword("asdfgh");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndValidPassword() {
		loginPage.setUsername("samykya-thanuku");
		loginPage.setPassword("13n31a04k9");
		loginPage.clickSubmitButton();		
	}
	@After
	public void tearDownEnv(){
		loginPage=null;
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.close();
		driver=null;
	}
}
