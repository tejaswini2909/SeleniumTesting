package com.cg.demotest.Demo2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.RegistrationPage;

public class RegistrationTest {
	public static WebDriver driver;
	private RegistrationPage registrationPage;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTestEnv() {
		driver.get("https://github.com/join?source=header-home");
		registrationPage = new RegistrationPage();
		PageFactory.initElements(driver, registrationPage);
	}

	private String getValidUsername() {
		return "samykya-thanuku";
	}
	private String getInvalidUsername() {
		return "sthanuku";
	}
	private String getValidPassword() {
		return "13n31a04k9";
	}
	private String getInvalidPassword() {
		return "karunya";
	}
	private String getValidEmailID() {
		return "samykya.sunny@gmail.com";
	}
	private String getInvalidEmailID() {
		return "sam@gmail.com";
	}

	@Test
	public  void testForBlankUserNameAndEmailAndPassword(){
		registrationPage.setUsername("");
		registrationPage.setPassword("");
		registrationPage.setEmailID("");
		registrationPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Login can't be blank,Email can't be blank,Password can't be blank and is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	
	@Test
	public void testForInvalidUserNameAndPassword(){
		registrationPage.setUsername(getInvalidUsername());
		registrationPage.setPassword(getInvalidPassword());
		registrationPage.setEmailID(getValidEmailID());
		registrationPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}

	@Test
	public void testForValidUserNameAndPasswordAndInvalidEmailId(){
		registrationPage.setUsername(getValidUsername());
		registrationPage.setPassword(getValidPassword());
		registrationPage.setEmailID(getInvalidEmailID());
		registrationPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}

	@Test
	public void testForInvalidUserNameAndPasswordAndEmailID(){
		registrationPage.setUsername(getInvalidUsername());
		registrationPage.setPassword(getInvalidPassword());
		registrationPage.setEmailID(getInvalidEmailID());
		registrationPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Email is invalid or already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}

	@Test
	public void testForInvalidPassword(){
		registrationPage.setUsername(getValidUsername());
		registrationPage.setPassword(getInvalidPassword());
		registrationPage.setEmailID(getValidEmailID());
		registrationPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	
	@Test
	public void testForValidUserNameAndPassword(){
		registrationPage.setUsername(getValidUsername());
		registrationPage.setPassword(getValidPassword());
		registrationPage.setEmailID(getValidEmailID());
		registrationPage.clickSubmitButton();
	}

	@After
	public void tearDownEnv(){
		registrationPage=null;
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.close();
		driver=null;
	}
}
