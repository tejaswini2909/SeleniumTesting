package com.cg.githublogintest.model;

import org.junit.After;
import org.junit.AfterClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage {
	@FindBy(id="user_login")
	WebElement username;

	@FindBy(id="user_email")
	WebElement emailID;

	

	@FindBy(id="user_password")
	WebElement password;

	@FindBy(className="btn")
	WebElement button;

	public RegisterPage() {}

	public WebElement getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}
	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void clickSubmitButton() {
		button.submit();
	}

	
}
